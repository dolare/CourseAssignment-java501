import javax.swing.JOptionPane;
public class C10E13TestMyRectangle2D {
	public static void main(String [] args){	
		double x = 0;
		double y = 0;
		double width = 0;
		double height = 0;
		double xTestP = 0;
		double yTestP = 0;
		double xTest = 0;
		double yTest = 0;
		double widthTest = 0;
		double heightTest = 0;
		String tempString;
		int option = JOptionPane.YES_OPTION;
		while(option == JOptionPane.YES_OPTION){
			
			JOptionPane.showMessageDialog(null, " Enter parameters of first rectangle ");
			int x1 = 0;
			while(x1 == 0){
				try{
					tempString = JOptionPane.showInputDialog(" Please enter the x-axes of the first Rectangle : ");
					x = Double.parseDouble(tempString);
					x1 = 1;
				}
				catch(Exception e){
					JOptionPane.showMessageDialog(null, " Error input, plesae enter again ");
				}
			}
			
			int y1 = 0;
			while(y1 == 0){
				try{
					tempString = JOptionPane.showInputDialog(" Please enter the y-axes of the first Rectangle : ");
					y = Double.parseDouble(tempString);
					y1 = 1;
				}
				catch(Exception e){
					JOptionPane.showMessageDialog(null, " Error input, plesae enter again ");
				}
			}
			
			int width1 = 0;
			while(width1 == 0){
				try{
					tempString = JOptionPane.showInputDialog(" Please enter the width of the first Rectangle : ");
					width = Double.parseDouble(tempString);
					if(width <= 0){
						Exception e = new Exception();
						throw e;	
					}
					width1 = 1;
				}
				catch(Exception e){
					JOptionPane.showMessageDialog(null, " Error input, plesae enter again ");
				}
			}
			
			int height1 = 0;
			while(height1 == 0){
				try{
					tempString = JOptionPane.showInputDialog(" Please enter the height of the first Rectangle : ");
					height = Double.parseDouble(tempString);
					if(height <= 0){
						Exception e = new Exception();
						throw e;	
					}
					height1 = 1;
				}
				catch(Exception e){
					JOptionPane.showMessageDialog(null, " Error input, plesae enter again ");
				}
			}
			while(option == JOptionPane.YES_OPTION){
				JOptionPane.showMessageDialog(null, " Enter parameters of the test point ");
				int x11 = 0;
				while(x11 == 0){
					try{
						tempString = JOptionPane.showInputDialog(" Please enter the x-axes of the test point : ");
						xTestP = Double.parseDouble(tempString);
						x11 = 1;
					}
					catch(Exception e){
						JOptionPane.showMessageDialog(null, " Error input, plesae enter again ");
					}
				}
				
				int y11 = 0;
				while(y11 == 0){
					try{
						tempString = JOptionPane.showInputDialog(" Please enter the y-axes of the test point : ");
						yTestP = Double.parseDouble(tempString);
						y11 = 1;
					}
					catch(Exception e){
						JOptionPane.showMessageDialog(null, " Error input, plesae enter again ");
					}
				}
				
				//enter test rectangle
				JOptionPane.showMessageDialog(null, " Enter parameters of the test rectangle ");
				
				int x111 = 0;
				while(x111 == 0){
					try{
						tempString = JOptionPane.showInputDialog(" Please enter the x-axes of the test Rectangle : ");
						xTest = Double.parseDouble(tempString);
						x111 = 1;
					}
					catch(Exception e){
						JOptionPane.showMessageDialog(null, " Error input, plesae enter again ");
					}
				}
				
				int y111 = 0;
				while(y111 == 0){
					try{
						tempString = JOptionPane.showInputDialog(" Please enter the y-axes of the test Rectangle : ");
						yTest = Double.parseDouble(tempString);
						y111 = 1;
					}
					catch(Exception e){
						JOptionPane.showMessageDialog(null, " Error input, plesae enter again ");
					}
				}
				
				int width11 = 0;
				while(width11 == 0){
					try{
						tempString = JOptionPane.showInputDialog(" Please enter the width of the test Rectangle : ");
						widthTest = Double.parseDouble(tempString);
						if(widthTest <= 0){
							Exception e = new Exception();
							throw e;	
						}
						width11 = 1;
					}
					catch(Exception e){
						JOptionPane.showMessageDialog(null, " Error input, plesae enter again ");
					}
				}
				
				int height11 = 0;
				while(height11 == 0){
					try{
						tempString = JOptionPane.showInputDialog(" Please enter the height of the test Rectangle : ");
						heightTest = Double.parseDouble(tempString);
						if(heightTest <= 0){
							Exception e = new Exception();
							throw e;	
						}
						height11 = 1;
					}
					catch(Exception e){
						JOptionPane.showMessageDialog(null, " Error input, plesae enter again ");
					}
			}
				MyRectangle2D r1 = new MyRectangle2D(x, y,width,height);
				if(r1.contains(xTestP, yTestP)){
					JOptionPane.showMessageDialog(null, " the test point is inside this rectangle");
				}else JOptionPane.showMessageDialog(null, " the test point is not inside this rectangle");
				if(r1.contains(new MyRectangle2D(xTest, yTest, widthTest, heightTest)))
					JOptionPane.showMessageDialog(null, " the test rectangle is inside this rectangle");
				else if(r1.overlaps(new MyRectangle2D(xTest, yTest, widthTest, heightTest)))
					JOptionPane.showMessageDialog(null, " the test rectangle overlaps with this rectangle");
				else
					JOptionPane.showMessageDialog(null, " the test point is outside this rectangle");
				
				option = JOptionPane.showConfirmDialog(null, "do you need test anthoer point and rectangle? ");
						
		}
			option = JOptionPane.showConfirmDialog(null, "do you need enter a new first rectangle?");
	}
		
	}
}

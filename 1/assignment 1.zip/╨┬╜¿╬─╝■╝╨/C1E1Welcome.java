import javax.swing.JOptionPane;

public class C1E1Welcome {
	public static void main ( String [] args){
		//display in the compiler
		System.out.println("Welcome to Java , Welcome to Comepuer Science , Programming is fun.");
		
		String output="Welcome to Java , Welcome to Comepuer Science , Programming is fun." ;
		
	  // display messages in a dialog box window
		JOptionPane.showMessageDialog (null, output);
	}
}
